###########################################################
"""

CAESAR CIPHER Decoder with Database Decryption Likelihood
v1 written Spring 2021 for MATH1350 at Harding University
v2 written Spring 2022
Last Updated: 28 January 2022

©Isaac Raymond 2021


"""
###########################################################

import math
import string

alphabet = string.ascii_lowercase
file = open("caesarwords.txt")
contents = file.read()

start = input("Press any key to begin: ")
continueCheck = ""

###########################################################

"""
FUNCTION DEFINITIONS

This section includes the caesarDecrypt function which will shift letters
according to a given positive (right) shift value, and a caesarLikely fu-
nction which searches for decrypted messages in a crossword database to
determine if the decryption is a likely English message.
"""

def caesarDecrypt(string, step, disUnlikely):
    decryptedMessage = ""
    output = ""
    decryptValid = True
    for letter in string:
        if (letter not in alphabet):
            decryptedMessage = decryptedMessage + " "
        else:
            decryptedMessage = decryptedMessage + str(alphabet[(alphabet.find(letter) - int(step)) % 26])

    for word in decryptedMessage.split():
        if "\n" + word + "\n" not in contents:
            decryptValid = False
        else:
            continue
            
    if decryptValid and disUnlikely:
        output = decryptedMessage + " - possible decryption"
    else:
        output = decryptedMessage
        
    return output


###########################################################

"""
PROGRAM BODY

This section includes the if statements that take user input and
run the appropriate functions as defined in the section above.
"""

while (continueCheck != "q"):
    enStr = input("What are we decoding?: ").lower() #inputs encoded message
    stepAmount = input("Please enter the step amount, or \"no\" if unknown, or \"help\" for an explanation: ") #inputs step amount or "no" if unknown or help menu if "help"

    if stepAmount == "help":
        print("<<<<<<<<HELP  MENU>>>>>>>>")
        print("--------------------------")
        print("Shift of 8 starting at M: ")
        print("    |<<<<<<<|             ")
        print("ABCDEFGHIJKLMNOPQRSTUVWXYZ")
        print("              results in E")
        print("--------------------------")
        print("Shift of -4 starting at M:")
        print("            |>>>|         ")
        print("ABCDEFGHIJKLMNOPQRSTUVWXYZ")
        print("              results in Q")
        print("--------------------------")
        stepAmount = input("Please enter the step amount, or \"no\" if unknown, or \"help\" for an explanation: ")

    
    if stepAmount != "no":
        displayUnlikely = "y"
    else:
        displayUnlikely = input("Display unlikely decryptions? (Please type \"y\" or \"n\"): ") #does the user want all results displayed?
    print("----------")
    if displayUnlikely == "y":
        if stepAmount == "no":
            for i in range(26):
                print(caesarDecrypt(enStr, i, True))
        else:
            print(caesarDecrypt(enStr, int(stepAmount), False))
            
    elif displayUnlikely == "n":
        if stepAmount == "no":
            for j in range(26): # check all possible shifts %26
                output = caesarDecrypt(enStr, j, False)
                if output is None: # doesn't display NoneType returns from caesarDecrypt function
                    continue
                else:
                    if enStr==output:
                        print(output + " - original string") # checks to see if output string is the original string (step = 0)
                    else:
                        print(output) # normal output
        else:
            print(caesarDecrypt(enStr, int(stepAmount), False))
            
    else:
        print("Please enter \"y\" or \"n\" next time.")
    print("----------")   
    continueCheck = input("Press \"q\" to quit, or any other key to continue decoding: ")

###########################################################
